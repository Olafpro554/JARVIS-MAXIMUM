package com.jarvis.maximum

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null

    private val recognizer = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let(::handle)
    }
    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) listen() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            JarvisScreen(
                onMic = {
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) listen()
                    else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                },
                onSend = ::handle
            )
        }
    }

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (ready) {
            tts?.setLanguage(Locale("es", "MX"))
            tts?.setSpeechRate(0.92f)
            tts?.setPitch(0.82f)
            pending?.let(::speak)
        }
    }

    private fun listen() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla con J.A.R.V.I.S.")
        }
        runCatching { recognizer.launch(intent) }.onFailure { speak("El reconocimiento de voz no está disponible.") }
    }

    private fun handle(raw: String) {
        val command = raw.trim()
        val lower = command.lowercase(Locale.ROOT)
        val answer = when {
            "hola" in lower -> "Buenas. J.A.R.V.I.S. está a su servicio."
            "tu nombre" in lower -> "Soy J.A.R.V.I.S. Maximum, su asistente personal."
            "abre whatsapp" in lower -> openApp("com.whatsapp", "WhatsApp")
            "abre youtube" in lower -> openApp("com.google.android.youtube", "YouTube")
            "abre chrome" in lower -> openApp("com.android.chrome", "Chrome")
            else -> "He recibido su solicitud: $command. El módulo de inteligencia artificial todavía no está conectado."
        }
        speak(answer)
    }

    private fun openApp(pkg: String, name: String): String {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) return "$name no está disponible."
        startActivity(intent)
        return "Abriendo $name."
    }

    private fun speak(text: String) {
        if (!ready) { pending = text; return }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-${System.currentTimeMillis()}")
    }

    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

@Composable
private fun JarvisScreen(onMic: () -> Unit, onSend: (String) -> Unit) {
    var input by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Sistemas en espera.") }
    val transition = rememberInfiniteTransition(label = "core")
    val pulse by transition.animateFloat(0.94f, 1.06f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "pulse")
    val background = Brush.verticalGradient(listOf(Color(0xFF020812), Color(0xFF061B2B), Color(0xFF02050B)))

    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF36D9FF), secondary = Color(0xFF00A6D6), background = Color(0xFF020812), surface = Color(0xFF071827))) {
        Column(Modifier.fillMaxSize().background(background).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(20.dp))
            Text("J.A.R.V.I.S.", color = Color(0xFF75E8FF), fontSize = 27.sp, fontWeight = FontWeight.Light, letterSpacing = 5.sp)
            Text("MAXIMUM  •  ASISTENTE PERSONAL", color = Color(0xFF4CA9C5), fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.weight(1f))
            Box(Modifier.size(250.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.size(235.dp).scale(pulse).border(1.dp, Color(0x5538DFFF), CircleShape))
                Box(Modifier.size(195.dp).border(2.dp, Color(0xAA20BFE8), CircleShape).padding(13.dp).border(1.dp, Color(0x6645DFFF), CircleShape))
                Box(Modifier.size(128.dp).background(Brush.radialGradient(listOf(Color(0xFF36DFFF), Color(0xFF0879B4), Color(0xFF031321))), CircleShape).border(2.dp, Color(0xFF83EDFF), CircleShape), contentAlignment = Alignment.Center) {
                    Text("J", color = Color.White, fontSize = 54.sp, fontWeight = FontWeight.ExtraLight)
                }
            }
            Spacer(Modifier.height(28.dp))
            Text("ESTADO DEL SISTEMA", color = Color(0xFF5BAFC9), fontSize = 10.sp, letterSpacing = 2.sp)
            Text(status, color = Color(0xFFD4F7FF), fontSize = 14.sp)
            Spacer(Modifier.weight(1f))
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Escriba una orden...") }, singleLine = true, shape = RoundedCornerShape(18.dp),
                trailingIcon = { IconButton(onClick = { if (input.isNotBlank()) { status = input; onSend(input); input = "" } }) { Icon(Icons.Default.Send, null, tint = Color(0xFF54DFFF)) } },
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color(0xFF39DFFF), unfocusedBorderColor = Color(0x6646BBD8), focusedTextColor = Color.White, unfocusedTextColor = Color.White)
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = onMic, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF087DAA))) {
                Icon(Icons.Default.Mic, null); Spacer(Modifier.width(10.dp)); Text("HABLAR CON J.A.R.V.I.S.", letterSpacing = 1.sp)
            }
            Spacer(Modifier.height(12.dp))
            Text("MODO LOCAL • VOZ ESPAÑOL", color = Color(0xFF43869B), fontSize = 10.sp)
        }
    }
}
