# J.A.R.V.I.S. MAXIMUM — base inicial

Proyecto Android nativo en Kotlin y Jetpack Compose.

## Incluido en esta primera entrega
- Interfaz holográfica inicial.
- Entrada de órdenes por texto.
- Reconocimiento de voz mediante el servicio instalado en Android.
- Síntesis de voz Android en español, si existe una voz compatible.
- Ajuste inicial de tono y velocidad.
- Comandos locales de ejemplo para abrir WhatsApp, YouTube y Chrome.

## Todavía no incluido
No es aún la versión MAXIMUM terminada. Falta integrar un modelo de IA, memoria persistente, activación por palabra clave, control multidispositivo, creación de archivos, llamadas completas y mensajería. La voz depende del motor y de las voces instaladas en el teléfono; no incluye ni clona la voz cinematográfica original.

## Compilación
Requiere JDK 17, Android SDK 35 y Gradle 8.9 o compatible.
Ejecuta `gradle wrapper --gradle-version 8.9` para generar el wrapper y luego `./gradlew assembleDebug`.
APK esperado: `app/build/outputs/apk/debug/app-debug.apk`.

No marques funciones como probadas hasta ejecutarlas en un dispositivo real.
